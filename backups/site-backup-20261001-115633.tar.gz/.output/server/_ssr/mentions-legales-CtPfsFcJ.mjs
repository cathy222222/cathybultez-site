import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as Header, t as Footer } from "./Footer-D6Y7gFWu.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/mentions-legales-CtPfsFcJ.js
var import_jsx_runtime = require_jsx_runtime();
function LegalPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-cream text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto max-w-4xl px-6 pb-24 pt-40 lg:px-12 lg:pt-48",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[13px] font-semibold uppercase tracking-[0.3em] text-gold",
						children: "Informations légales"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-6 font-display text-5xl font-light leading-tight sm:text-6xl",
						children: "Mentions légales"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-16 space-y-12 text-base font-light leading-relaxed text-inkmuted sm:text-lg",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-3xl font-medium text-ink",
									children: "1. Présentation du site"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4",
									children: "Le site cathybultez.com est édité par Cathy BULTEZ, micro-entreprise, immatriculée sous le numéro SIRET 908 819 618 00046, domiciliée à 59730 Romeries."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-4",
									children: [
										"Responsable de la publication et webmaster : Cathy BULTEZ.",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
										"Contact : cathybultez@hotmail.com"
									]
								})
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-3xl font-medium text-ink",
								children: "2. Hébergement"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-4",
								children: [
									"Le site est hébergé par Wix.com. Pour plus d'informations :",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: "https://www.wix.com",
										target: "_blank",
										rel: "noreferrer",
										className: "text-gold underline underline-offset-4",
										children: "wix.com"
									})
								]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-3xl font-medium text-ink",
									children: "3. Description des services"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4",
									children: "Les informations publiées sur ce site sont données à titre indicatif et peuvent évoluer. Cathy BULTEZ s'efforce de fournir des informations exactes et à jour, sans pouvoir garantir l'absence d'omissions ou d'inexactitudes."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4",
									children: "Les soins énergétiques et massages proposés ne constituent pas des actes médicaux. Aucun diagnostic médical n'est posé et aucun traitement ne doit être modifié ou interrompu sans l'avis du médecin traitant ou spécialiste."
								})
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-3xl font-medium text-ink",
								children: "4. Propriété intellectuelle"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4",
								children: "Cathy BULTEZ est propriétaire des droits de propriété intellectuelle ou détient les droits d'usage sur les éléments accessibles sur le site. Toute reproduction, représentation, modification ou adaptation non autorisée de tout ou partie du site est interdite."
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-3xl font-medium text-ink",
								children: "5. Responsabilité"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4",
								children: "L'utilisateur accède au site avec un matériel récent, protégé et utilisant un navigateur à jour. Cathy BULTEZ ne pourra être tenue responsable des dommages directs ou indirects liés à l'accès ou à l'utilisation du site, notamment en cas de bug, d'incompatibilité ou d'interruption."
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-3xl font-medium text-ink",
									children: "6. Données personnelles"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4",
									children: "Les messages transmis par e-mail sont utilisés uniquement pour répondre aux demandes. Conformément à la réglementation applicable, toute personne peut demander l'accès, la rectification ou la suppression de ses données en écrivant à cathybultez@hotmail.com."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4",
									children: "Le thérapeute est tenu au secret professionnel et à la confidentialité."
								})
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "border-t border-ink/10 pt-8 text-sm",
								children: "Dernière mise à jour : septembre 2026. SIRET : 908 819 618 00046."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "mt-12 inline-flex rounded-full border border-ink/15 px-6 py-3 text-sm font-semibold uppercase tracking-[0.15em] text-ink transition-colors hover:border-gold hover:bg-gold hover:text-cream",
						children: "Retour à l'accueil"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
		]
	});
}
//#endregion
export { LegalPage as component };
