import { n as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { a as Mail, c as Facebook, i as MapPin, n as Phone, r as Menu, t as X, u as ArrowUp } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/Footer-D6Y7gFWu.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var navLinks = [
	{
		label: "L'approche",
		href: "/#approche"
	},
	{
		label: "Soins",
		href: "/#soins"
	},
	{
		label: "À propos",
		href: "/#a-propos"
	},
	{
		label: "Bon cadeau",
		href: "/#bon-cadeau"
	},
	{
		label: "Contact",
		href: "/#contact"
	}
];
function Header() {
	const [scrolled, setScrolled] = (0, import_react.useState)(false);
	const [mobileOpen, setMobileOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const onScroll = () => setScrolled(window.scrollY > 40);
		onScroll();
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => window.removeEventListener("scroll", onScroll);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: `fixed inset-x-0 top-0 z-[100] transition-all duration-500 ${scrolled ? "border-b border-ink/10 bg-cream/85 backdrop-blur-md" : "border-b border-transparent bg-transparent"}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "mx-auto flex max-w-7xl items-center justify-between px-6 py-5 lg:px-12",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: "/",
						className: "flex flex-col text-ink",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-display text-2xl font-medium tracking-tight",
							children: ["Cathy ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "italic text-gold",
								children: "Bultez"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-0.5 text-[9px] font-semibold uppercase tracking-[0.12em] text-ink/60",
							children: "Romeries - Région hauts de France - 59"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "hidden items-center gap-8 lg:flex",
						children: navLinks.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: link.href,
							className: "relative text-[13px] font-medium uppercase tracking-[0.18em] text-ink/70 transition-colors hover:text-ink after:absolute after:-bottom-1 after:left-0 after:h-px after:w-0 after:bg-gold after:transition-all after:duration-300 hover:after:w-full",
							children: link.label
						}, link.href))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "hidden lg:block",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "tel:0610197558",
							className: "group inline-flex items-center gap-2.5 rounded-full border border-ink/15 px-5 py-2.5 text-[13px] font-semibold tracking-wide text-ink transition-all duration-300 hover:border-gold hover:bg-gold hover:text-cream",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "h-3.5 w-3.5 transition-transform duration-300 group-hover:rotate-12" }), "06 10 19 75 58"]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "inline-flex h-11 w-11 items-center justify-center rounded-full border border-ink/15 text-ink lg:hidden",
						onClick: () => setMobileOpen(true),
						"aria-label": "Ouvrir le menu",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "h-5 w-5" })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `fixed inset-0 z-[110] bg-ink/30 backdrop-blur-sm transition-opacity duration-300 lg:hidden ${mobileOpen ? "opacity-100" : "pointer-events-none opacity-0"}`,
				onClick: () => setMobileOpen(false)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `fixed right-0 top-0 z-[120] h-full w-80 max-w-[85vw] transform bg-cream p-7 shadow-2xl transition-transform duration-500 ease-out lg:hidden ${mobileOpen ? "translate-x-0" : "translate-x-full"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-2xl font-medium text-ink",
						children: "Menu"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "inline-flex h-11 w-11 items-center justify-center rounded-full border border-ink/15 text-ink",
						onClick: () => setMobileOpen(false),
						"aria-label": "Fermer le menu",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" })
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "mt-10 flex flex-col gap-1",
					children: [navLinks.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: link.href,
						onClick: () => setMobileOpen(false),
						className: "rounded-2xl px-4 py-3.5 font-display text-2xl font-light text-ink transition-colors hover:bg-sand",
						children: link.label
					}, link.href)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: "tel:0610197558",
						onClick: () => setMobileOpen(false),
						className: "mt-6 inline-flex items-center justify-center gap-2 rounded-full bg-gold px-6 py-3.5 text-sm font-semibold text-cream transition-colors hover:bg-golddeep",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "h-4 w-4" }), "06 10 19 75 58"]
					})]
				})]
			})
		]
	});
}
var nd_vertigneul_default = "/assets/nd-vertigneul-_UZr-fh0.png";
function Footer() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		id: "contact",
		className: "relative overflow-hidden bg-olive pt-24 text-cream lg:pt-32",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute -left-40 top-0 h-[30rem] w-[30rem] rounded-full bg-goldbright/15 blur-3xl" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute -right-32 bottom-0 h-[26rem] w-[26rem] rounded-full bg-sanddeep/10 blur-3xl" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: nd_vertigneul_default,
				alt: "",
				"aria-hidden": true,
				className: "pointer-events-none absolute left-1/2 top-4 w-auto max-w-none -translate-x-1/2 object-contain opacity-80 mix-blend-multiply",
				style: {
					height: "min(60vw, 30rem)",
					WebkitMaskImage: "radial-gradient(ellipse 70% 70% at 50% 50%, black 60%, transparent 92%)",
					maskImage: "radial-gradient(ellipse 70% 70% at 50% 50%, black 60%, transparent 92%)"
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto max-w-7xl px-6 lg:px-12",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "reveal text-[13px] font-semibold uppercase tracking-[0.3em] text-cream/70",
							children: "Contactez-moi"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "reveal mt-6 font-display text-5xl font-light leading-[1.05] tracking-tight sm:text-6xl lg:text-7xl",
							children: [
								"Prenez soin de vous,",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "italic text-sanddeep",
									children: "je vous accompagne"
								}),
								"."
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "reveal mt-40 flex flex-col items-center justify-center gap-4 sm:flex-row sm:gap-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "tel:0610197558",
							className: "group inline-flex items-center gap-3 rounded-full bg-cream px-8 py-4 text-base font-semibold text-ink transition-all duration-300 hover:bg-sanddeep",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "h-4 w-4 transition-transform duration-300 group-hover:rotate-12" }), "06 10 19 75 58"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "mailto:cathybultez@hotmail.com",
							className: "group inline-flex items-center gap-3 rounded-full border border-cream/40 px-8 py-4 text-base font-medium text-cream transition-all duration-300 hover:border-cream hover:bg-cream/10",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "h-4 w-4" }), "cathybultez@hotmail.com"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "reveal mt-20 grid gap-10 border-t border-cream/20 pt-14 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center sm:text-left",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-center gap-2 text-sanddeep sm:justify-start",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-[13px] font-semibold uppercase tracking-[0.25em]",
										children: "Le cabinet"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-4 font-display text-xl font-light leading-snug",
									children: [
										"Cathy Bultez",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
										"59730 Romeries",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
										"Hauts-de-France"
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center sm:text-left",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-[13px] font-semibold uppercase tracking-[0.25em] text-sanddeep",
									children: "Prise de rendez-vous"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-4 font-light leading-relaxed text-cream/85",
									children: [
										"Par téléphone ou par e-mail.",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
										"Séances à distance ou en présentiel."
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center sm:text-left",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-[13px] font-semibold uppercase tracking-[0.25em] text-sanddeep",
									children: "Règlement"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 font-light leading-relaxed text-cream/85",
									children: "Chèque, espèces ou RIB acceptés."
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "reveal mt-14 flex flex-wrap justify-center gap-x-8 gap-y-4 border-t border-cream/20 pt-8 text-xs font-semibold uppercase tracking-[0.18em] text-cream/70 sm:justify-start",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "https://www.google.com/maps/place/Cathy+Bultez+-+Praticienne+en+Massages+et+Bien-Etre/@50.2445525,3.6416956,17z/data=!3m1!4b1!4m6!3m5!1s0x47c28bbe74794fd9:0x94daa5c5b0e3d7e!8m2!3d50.2445525!4d3.6442705!16s%2Fg%2F11krdl445g?entry=ttu",
								target: "_blank",
								rel: "noreferrer",
								className: "transition-colors hover:text-cream",
								children: "Avis Google"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: "https://www.facebook.com/BultezCathy/",
								target: "_blank",
								rel: "noreferrer",
								className: "inline-flex items-center gap-2 transition-colors hover:text-cream",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Facebook, { className: "h-3.5 w-3.5" }), "Facebook"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "/mentions-legales",
								className: "transition-colors hover:text-cream",
								children: "Mentions légales"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-14 flex flex-col items-center justify-between gap-6 border-t border-cream/20 py-8 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs tracking-wide text-cream/60",
							children: [
								"© ",
								(/* @__PURE__ */ new Date()).getFullYear(),
								" Cathy Bultez — Thérapeute Énergétique · Massothérapeute"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "#",
							className: "group inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.25em] text-cream/70 transition-colors hover:text-cream",
							children: ["Retour en haut", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, { className: "h-3.5 w-3.5 transition-transform duration-300 group-hover:-translate-y-1" })]
						})]
					})
				]
			})
		]
	});
}
//#endregion
export { Header as n, Footer as t };
