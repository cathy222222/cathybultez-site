//#region node_modules/.nitro/vite/services/ssr/assets/routes-BW15OjnC.js
var IMAGES = {
	massage: "https://images.unsplash.com/photo-1598901986949-f593ff2a31a6?auto=format&fit=crop&w=1600&q=80",
	stones: "https://images.pexels.com/photos/34279942/pexels-photo-34279942.jpeg?auto=compress&cs=tinysrgb&w=1600",
	silhouette: "https://images.unsplash.com/photo-1461468611824-46457c0e11fd?auto=format&fit=crop&w=1600&q=80",
	roseCrystals: "/assets/femme-apais%C3%A9e-mer-PjJlneUk.jpg",
	warmHands: "https://images.unsplash.com/photo-1515377905703-c4788e51af15?auto=format&fit=crop&w=1800&q=80",
	divineHands: "/assets/Mains%20divines-DmSHRmD4.png"
};
//#endregion
export { IMAGES as t };
