//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BVNEeawG.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspaces/html-site-builder-00/src/routes/__root.tsx",
		children: ["/", "/mentions-legales"],
		preloads: ["/assets/index-BFrZHLBS.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BFrZHLBS.js"
		} }]
	},
	"/": {
		filePath: "/workspaces/html-site-builder-00/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CDpYF6aZ.js", "/assets/Footer-DCpZmgmL.js"]
	},
	"/mentions-legales": {
		filePath: "/workspaces/html-site-builder-00/src/routes/mentions-legales.tsx",
		children: void 0,
		preloads: ["/assets/mentions-legales-l9EQQnGN.js", "/assets/Footer-DCpZmgmL.js"]
	}
} });
//#endregion
export { tsrStartManifest };
