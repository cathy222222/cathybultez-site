//#region node_modules/.nitro/vite/services/ssr/assets/routes-DSFc6h4_.js
var IMAGES = {
	massage: "https://images.unsplash.com/photo-1598901986949-f593ff2a31a6?auto=format&fit=crop&w=1600&q=80",
	stones: "https://images.pexels.com/photos/34279942/pexels-photo-34279942.jpeg?auto=compress&cs=tinysrgb&w=1600",
	silhouette: "https://images.unsplash.com/photo-1461468611824-46457c0e11fd?auto=format&fit=crop&w=1600&q=80"
};
//#endregion
export { IMAGES as t };
