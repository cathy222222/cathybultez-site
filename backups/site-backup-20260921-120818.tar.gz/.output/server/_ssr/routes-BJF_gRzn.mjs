import { n as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { d as ArrowDown, l as ChevronDown, n as Phone, o as Heart, s as Gift, t as X } from "../_libs/lucide-react.mjs";
import { n as Header, t as Footer } from "./Footer-D6Y7gFWu.mjs";
import { t as IMAGES } from "./routes-DSFc6h4_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BJF_gRzn.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Fleur_de_vie_default = "/assets/Fleur%20de%20vie-DHEuVFY4.png";
var soin_mains_tete_default = "/assets/soin-mains-tete-DPxg62nW.jpg";
var femme_apaisée_mer_default = "/assets/femme-apais%C3%A9e-mer-PjJlneUk.jpg";
var marqueeWords = [
	"Bien-être",
	"Lâcher-prise",
	"Énergie",
	"Sérénité",
	"Harmonie corporelle"
];
var motifs = [
	"Fatigue",
	"Blocages dans plusieurs domaines",
	"Stress",
	"Angoisses",
	"Anxiété",
	"Dépression",
	"Burn out",
	"Insomnies",
	"Traumatismes physiques & psychiques",
	"Deuil",
	"Addictions",
	"Manque de concentration",
	"Manque de confiance en soi",
	"Douleurs corporelles",
	"Trauma corporel",
	"Accompagnement de la maladie",
	"Accompagnement spirituel en fin de vie"
];
var soins = [
	{
		num: "01",
		title: "Accompagnement thérapeutique",
		description: "Une thérapie demande généralement plusieurs séances, selon votre besoin et votre évolution. Selon les situations, différents outils peuvent être mobilisés : libération par la parole, rééquilibrage énergétique, nettoyage mémoires émotionnelles, prénatales, transgénérationnelles et karmiques, sophronisation thérapeutique, bol chantant tibétain, tambour… Chaque séance est une parenthèse : un temps pour déposer les tensions, apaiser le mental et relancer la circulation de l'énergie vitale.",
		meta: [
			{
				label: "Durée",
				value: "1 h 30"
			},
			{
				label: "Prix",
				value: "60 €"
			},
			{
				label: "Lieu",
				value: "À distance ou en présentiel au cabinet de Romeries"
			}
		]
	},
	{
		num: "02",
		title: "Soin des 2 couronnes",
		description: "Je vous propose également des soins pour vous aider dans la relation parents/enfants, les problèmes dans les fratries. Un soin puissant qui règle certaines problématiques entre un parent et son enfant, entre une fratrie, apporte des libérations, des compréhensions, de l'apaisement. Il peut également être réalisé avec un proche défunt.",
		description2: "Ce soin peut aussi être fait individuellement pour vous rééquilibrer énergétiquement et émotionnellement, vous libérer et enlever des blocages.",
		meta: [
			{
				label: "Prix",
				value: "90 € pour 2 personnes"
			},
			{
				label: "Individuel",
				value: "45 €"
			},
			{
				label: "Lieu",
				value: "À distance sur photos"
			}
		]
	},
	{
		num: "03",
		title: "Soin d'urgence à distance",
		description: "Un soin énergétique proposé à distance pour accompagner les situations d'urgence, notamment les douleurs ou les crises d'angoisse.",
		meta: [{
			label: "Prix",
			value: "40 €"
		}, {
			label: "Lieu",
			value: "À distance"
		}]
	},
	{
		num: "04",
		title: "Massage Énergétique Intuitif du Corps",
		description: "Un massage personnalisé qui associe l'écoute du corps, le toucher et l'intuition. Chaque séance est adaptée à la personne et à ses besoins du moment — une démarche favorisant le lâcher-prise, la reconnexion à soi et la libération des tensions émotionnelles.",
		extra: [
			{
				label: "Avant la séance",
				text: "Arrivez détendu·e, prenez une douche ou un bain, évitez de crémer le corps et de trop manger juste avant."
			},
			{
				label: "Déroulement",
				text: "Les zones non massées restent couvertes, les sous-vêtements sont conservés. Le massage concerne le dos, le ventre, les jambes, les bras et la tête."
			},
			{
				label: "Précautions",
				text: "Grossesse et allaitement, épilepsie, cancers hormono-dépendants, certains traitements, problèmes cutanés, hypersensibilité, enfants de moins de 10 ans."
			},
			{
				label: "Huiles de massage",
				text: "2 choix possibles contenant des huiles essentielles (huile végétale neutre possible en cas d'allergie, à signaler à la prise de rendez-vous).",
				note: "Option : huiles issues du Massage Énergétique des 5 Continents : 85 € en cabinet, 90 € en extérieur\nJusqu'à épuisement des stocks."
			}
		],
		meta: [
			{
				label: "Durée",
				value: "1 h 30"
			},
			{
				label: "Prix",
				value: "80 € · Cabinet de Romeries"
			},
			{
				label: "",
				value: "85 € · Extérieur SPA, maisons d'hôtes"
			},
			{
				label: "Option huiles 5 Continents:",
				value: "85 € en cabinet · 90 € en extérieur"
			}
		]
	},
	{
		num: "05",
		title: "Massage Assis Énergétique Intuitif",
		description: "Reçu habillé, en position assise sur une chaise ergonomique conçue à cette fin. Il s'effectue au niveau des épaules, du dos, de la nuque, des hanches, des bras, des mains et de la tête. Apaisant et profondément relaxant, il rééquilibre le corps, améliore la circulation, soulage les tensions nerveuses et dynamise l'organisme tout entier. Il stimule les méridiens d'acupuncture et aide à soulager les affections causées par le stress : maux de dos, migraines, épuisement, insomnies…",
		meta: [
			{
				label: "Durée",
				value: "45 mn"
			},
			{
				label: "Prix",
				value: "45 € · Cabinet de Romeries"
			},
			{
				label: "Extérieur",
				value: "Me consulter"
			},
			{
				label: "Options",
				value: "Temps réduits possibles (15, 20, 30 mn) — entreprises, CE, institutions, résidences seniors"
			},
			{
				label: "À domicile",
				value: "Déplacement possible chez les personnes âgées"
			}
		]
	},
	{
		num: "06",
		title: "Nettoyage énergétique de lieux",
		description: "Les lieux et les bâtiments ont des mémoires, liées aux habitants, à l'histoire des lieux ou à l'environnement — générant parfois des blocages : difficultés à vendre, disputes, problèmes de sommeil ou de santé. Un nettoyage énergétique élimine entités, mauvaises énergies et mémoires pour remettre de belles énergies et protections. Je conseille toujours un nettoyage avant d'emménager dans une nouvelle maison.",
		meta: [{
			label: "Prestation",
			value: "À distance"
		}, {
			label: "Prix",
			value: "Sur devis"
		}]
	}
];
var reactions = [
	{
		title: "Libération émotionnelle",
		text: "Des émotions ou sensations peuvent réapparaître temporairement après la séance."
	},
	{
		title: "Fatigue ou énergie",
		text: "Une sensation de fatigue ou, au contraire, de dynamisme peut être ressentie."
	},
	{
		title: "Légèreté",
		text: "Une sensation de légèreté peut accompagner le vécu de la séance."
	},
	{
		title: "Douleurs",
		text: "Les sensations corporelles peuvent évoluer au fil du travail et des prises de conscience."
	},
	{
		title: "Sensibilité émotionnelle",
		text: "Une période de sensibilité accrue peut être ressentie après le soin."
	},
	{
		title: "Pas de sensation",
		text: "Chaque personne ayant une sensibilité différente, l'absence de sensation pendant la séance est possible."
	}
];
var formations = [
	"Psycho-Sophrologue",
	"Énergétique",
	"Massage des 5 Continents",
	"Massage Métamorphique",
	"Massage Assis Amma"
];
function useReveal() {
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const root = ref.current ?? document;
		const els = Array.from(root.querySelectorAll(".reveal"));
		if (!("IntersectionObserver" in window)) {
			els.forEach((el) => el.classList.add("is-visible"));
			return;
		}
		const io = new IntersectionObserver((entries) => {
			for (const entry of entries) if (entry.isIntersecting) {
				entry.target.classList.add("is-visible");
				io.unobserve(entry.target);
			}
		}, { threshold: .12 });
		els.forEach((el) => io.observe(el));
		return () => io.disconnect();
	}, []);
	return ref;
}
function Eyebrow({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "reveal flex items-center justify-center gap-3 text-[13px] font-semibold uppercase tracking-[0.3em] text-gold",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px w-8 bg-gold/60" }),
			children,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px w-8 bg-gold/60" })
		]
	});
}
var COHERENCE_TOTAL = 300;
function CoherenceCardiaque() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [running, setRunning] = (0, import_react.useState)(false);
	const [phase, setPhase] = (0, import_react.useState)("out");
	const [secondsLeft, setSecondsLeft] = (0, import_react.useState)(COHERENCE_TOTAL);
	const finished = !running && secondsLeft === 0;
	const started = secondsLeft < COHERENCE_TOTAL || running;
	const close = () => {
		setOpen(false);
		setRunning(false);
		setSecondsLeft(COHERENCE_TOTAL);
		setPhase("out");
	};
	const start = () => {
		setSecondsLeft(COHERENCE_TOTAL);
		setPhase("out");
		setRunning(true);
	};
	(0, import_react.useEffect)(() => {
		if (!running) return;
		const t = setTimeout(() => setPhase((p) => p === "in" ? "out" : "in"), 5e3);
		return () => clearTimeout(t);
	}, [running, phase]);
	(0, import_react.useEffect)(() => {
		if (!running) return;
		const i = setInterval(() => {
			setSecondsLeft((s) => {
				if (s <= 1) {
					setRunning(false);
					return 0;
				}
				return s - 1;
			});
		}, 1e3);
		return () => clearInterval(i);
	}, [running]);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const onKey = (e) => {
			if (e.key === "Escape") close();
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [open]);
	const mm = String(Math.floor(secondsLeft / 60)).padStart(1, "0");
	const ss = String(secondsLeft % 60).padStart(2, "0");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: () => setOpen(true),
		className: "group mt-10 inline-flex items-center gap-3 rounded-full border border-ink/15 bg-cream/70 px-6 py-3 text-[12px] font-semibold uppercase tracking-[0.2em] text-ink backdrop-blur-sm transition-all duration-300 hover:border-gold hover:bg-gold hover:text-cream sm:text-[13px]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "h-4 w-4 animate-pulse" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex flex-col items-center gap-0.5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Cohérence cardiaque · 5 min" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-[10px] tracking-[0.25em] text-ink/55",
				children: "cliquez"
			})]
		})]
	}), open && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		role: "dialog",
		"aria-modal": "true",
		"aria-label": "Cohérence cardiaque — respiration guidée",
		className: "fixed inset-0 z-[200] flex flex-col items-center justify-center overflow-hidden px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-b from-cream via-creamsoft to-sand" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: close,
				"aria-label": "Fermer la cohérence cardiaque",
				className: "absolute right-5 top-5 z-10 inline-flex h-11 w-11 items-center justify-center rounded-full border border-ink/15 text-ink transition-colors hover:border-gold hover:bg-gold hover:text-cream",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative flex flex-col items-center text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "flex items-center gap-3 text-[13px] font-semibold uppercase tracking-[0.3em] text-gold",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px w-8 bg-gold/60" }),
						"Cohérence cardiaque",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px w-8 bg-gold/60" })
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-md font-display text-xl font-light italic leading-relaxed text-ink/70",
					children: "Installez-vous confortablement, respirez doucement au rythme du cercle — 5 secondes d'inspiration, 5 secondes d'expiration."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mt-12 flex h-64 w-64 items-center justify-center sm:h-80 sm:w-80",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute inset-0 rounded-full border border-gold/40" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute inset-5 rounded-full border border-gold/25" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute inset-0 flex items-center justify-center",
						"aria-hidden": true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex h-40 w-40 flex-col items-center justify-center rounded-full bg-gold/15 sm:h-56 sm:w-56",
							style: {
								transform: finished ? "scale(1)" : phase === "in" ? "scale(1.2)" : "scale(0.75)",
								transition: running ? "transform 5s ease-in-out" : "transform 1.2s ease-in-out"
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "h-6 w-6 text-gold" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 font-display text-xl font-light italic text-ink sm:text-2xl",
								children: !started ? "Prête ?" : finished ? "Session terminée ✦" : running ? phase === "in" ? "Inspirez" : "Expirez" : "Pause"
							})]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "relative mt-8 font-display text-3xl font-light tabular-nums text-ink/80",
				children: [
					mm,
					":",
					ss
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mt-10 flex flex-col items-center gap-4 sm:flex-row",
				children: [!running ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: start,
					className: "rounded-full bg-gold px-8 py-3.5 text-sm font-semibold tracking-wide text-cream transition-colors hover:bg-golddeep",
					children: finished ? "Recommencer une session" : started ? "Reprendre" : "Commencer · 5 minutes"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setRunning(false),
					className: "rounded-full border border-ink/15 px-8 py-3.5 text-sm font-semibold tracking-wide text-ink transition-colors hover:border-gold hover:bg-gold hover:text-cream",
					children: "Faire une pause"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: close,
					className: "text-[13px] font-semibold uppercase tracking-[0.2em] text-ink/60 transition-colors hover:text-ink",
					children: "Fermer"
				})]
			})
		]
	})] });
}
function HuilesMassageDetails() {
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => setOpen((value) => !value),
			"aria-expanded": open,
			className: "inline-flex items-center gap-2 text-sm font-semibold text-gold transition-colors hover:text-golddeep",
			children: [open ? "Masquer les huiles" : "Découvrir les huiles", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: `h-4 w-4 transition-transform ${open ? "rotate-180" : ""}` })]
		}), open && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-5 space-y-7 border-t border-ink/10 pt-5 text-sm leading-relaxed text-inkmuted",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
					className: "font-display text-2xl font-medium text-ink",
					children: "Sérénité Zen"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3",
					children: "Cette huile de massage est constituée d'huiles végétales et d'un mélange léger d'huiles essentielles d'orange et de lavandin, permettant d'accentuer la sensation de bien-être liée à un massage intense. Relâchez-vous complètement de manière à évacuer les petits tracas du quotidien."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3",
					children: "Cette huile et son parfum fruité vous permettront de vous évader et de vous détendre pleinement."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
						className: "font-semibold text-ink",
						children: "Composition :"
					}), " huiles végétales bio de Tournesol, Sésame, Amande douce et huiles essentielles bio (3,75 %) Orange, Petit grain, Lavandin grosso."]
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
					className: "font-display text-2xl font-medium text-ink",
					children: "Relaxation"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3",
					children: "L'huile de massage relaxation est une synergie de 7 huiles essentielles biologiques. Elle a été spécialement formulée pour aider à lutter contre les tensions physiques et le stress au quotidien. Elle est formulée avec des huiles essentielles biologiques reconnues pour leurs propriétés relaxantes et décontractantes."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
						className: "font-semibold text-ink",
						children: "Composition :"
					}), " formulée avec les 7 huiles essentielles de Ylang-ylang, Lavandin, Petit grain, Lavande, Mandarine verte, Bergamote, Orange douce, ainsi qu'un extrait de Vanille aux propriétés apaisantes."]
				})
			] })]
		})]
	});
}
function HomePage() {
	const pageRef = useReveal();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: pageRef,
		className: "min-h-screen bg-cream text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative flex min-h-screen flex-col justify-between overflow-hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "absolute inset-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: femme_apaisée_mer_default,
							alt: "",
							className: "h-full w-full object-cover object-center",
							width: 1024,
							height: 1280
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-b from-cream/75 via-cream/60 to-cream" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative flex flex-1 flex-col justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto w-full max-w-7xl px-6 pt-40 text-center sm:pt-48 lg:px-12 lg:pt-56",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: "sr-only",
									children: "Cathy Bultez — Thérapeute Énergétique · Massothérapeute à Romeries"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-base font-bold uppercase tracking-[0.35em] text-ink/70 sm:text-lg",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Thérapeute Énergétique · Massothérapeute" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mx-auto mt-10 max-w-xl text-base font-light leading-relaxed text-inkmuted sm:text-lg",
									children: "Libérer les émotions, rééquilibrer les énergies, retrouver la paix intérieure."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mx-auto mt-4 max-w-xl text-base font-light leading-relaxed text-inkmuted sm:text-lg",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "RDV à distance, en présentiel ou à domicile." })
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto flex w-full max-w-7xl flex-col items-center gap-10 px-6 pb-10 lg:px-12",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("blockquote", {
									className: "hidden max-w-md text-center sm:block",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-display text-lg font-light italic leading-relaxed text-ink/70",
										children: "« Les maux du corps sont les mots de l'âme. Ainsi on ne doit pas guérir le corps sans chercher à guérir l'âme. »"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("cite", {
										className: "mt-3 block text-xs font-semibold uppercase tracking-[0.25em] not-italic text-gold",
										children: "— Platon"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex justify-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CoherenceCardiaque, {})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: "#approche",
									className: "group flex items-center gap-3 text-xs font-semibold uppercase tracking-[0.25em] text-ink/60 transition-colors hover:text-ink",
									children: ["Découvrir", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "flex h-10 w-10 items-center justify-center rounded-full border border-ink/20 transition-all duration-300 group-hover:border-gold group-hover:bg-gold group-hover:text-cream",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, { className: "h-4 w-4 animate-bounce" })
									})]
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "relative border-t border-ink/10 py-5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex overflow-hidden",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "animate-marquee flex shrink-0 items-center",
								children: [...marqueeWords, ...marqueeWords].map((word, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-8 pr-8 font-display text-2xl font-light italic text-ink/50",
									children: [word, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-gold",
										children: "✦"
									})]
								}, i))
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "animate-marquee flex shrink-0 items-center",
								"aria-hidden": true,
								children: [...marqueeWords, ...marqueeWords].map((word, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-8 pr-8 font-display text-2xl font-light italic text-ink/50",
									children: [word, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-gold",
										children: "✦"
									})]
								}, i))
							})]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				id: "approche",
				className: "relative mx-auto max-w-7xl scroll-mt-24 overflow-hidden px-6 py-28 lg:px-12 lg:py-40",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: Fleur_de_vie_default,
						alt: "",
						"aria-hidden": "true",
						className: "pointer-events-none absolute left-1/2 -top-8 z-0 h-56 w-56 -translate-x-1/2 object-contain opacity-20 sm:-top-12 sm:h-64 sm:w-64",
						width: 5760,
						height: 3456
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative z-10 mx-auto max-w-3xl pt-8 text-center sm:pt-10",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: "Mon approche" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "reveal mt-8 font-display text-5xl font-light leading-[1.05] tracking-tight sm:text-6xl",
							children: [
								"Vous guider sur la voie du ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "italic text-gold",
									children: "bien-être"
								}),
								"."
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto mt-16 grid items-center gap-12 lg:grid-cols-[0.8fr_1.2fr] lg:gap-20",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "reveal relative mx-auto w-full max-w-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "overflow-hidden rounded-[2rem]",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: soin_mains_tete_default,
									alt: "Soin énergétique avec les mains posées près de la tête",
									className: "aspect-[4/5] w-full object-cover transition-transform duration-700 hover:scale-105",
									loading: "lazy",
									width: 1024,
									height: 1280
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -bottom-5 -right-4 -z-10 h-full w-full rounded-[2rem] border border-goldline sm:-right-5" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-6 text-base font-light leading-relaxed text-inkmuted sm:text-lg",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "reveal font-display text-xl font-medium italic text-ink sm:text-2xl",
									children: "Se faire accompagner par un·e thérapeute énergétique, ça sert à quoi ?"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "reveal",
									children: "À amener des libérations émotionnelles, des déblocages dans les situations de vie, des guérisons physiques… Les maladies ou les sensations de mal-être ont bien souvent une cause émotionnelle. Nous allons ensemble chercher cette cause, enlever les mémoires cellulaires liées aux événements douloureux — vécus de façon consciente ou même inconsciente — et rétablir l'équilibre énergétique défaillant."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "reveal",
									children: "Tout ceci vous amenant à terme à revoir certains schémas de pensées et de comportements, à vous sentir en paix intérieurement. En complément d'un accompagnement, viendra parfois se glisser un massage énergétique pour libérer les émotions cristallisées dans les organes et qu'on n'arrive pas à exprimer. Et inversement, certaines personnes commenceront par un massage et continueront avec un accompagnement."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "reveal",
									children: "N'oublions pas le monde de nos envolés. Je constate bien souvent que ce sont vos défunts qui nous amènent à nous rencontrer — soit parce qu'ils veulent vous aider, soit parce qu'ils ont besoin d'aide."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("blockquote", {
									className: "reveal border-l-2 border-gold pl-6",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-display text-2xl font-light italic leading-snug text-ink",
										children: "« Quel beau cadeau, au final, vous vous faites. »"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("cite", {
										className: "mt-3 block text-xs font-semibold uppercase tracking-[0.25em] not-italic text-gold",
										children: "Prenez soin de vous — Cathy"
									})]
								})
							]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "border-y border-ink/10 bg-sand py-28 lg:py-36",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-7xl px-6 lg:px-12",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-4xl text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: "Le toucher, l'écoute, l'intuition" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "reveal mt-8 font-display text-5xl font-light leading-[1.05] tracking-tight sm:text-6xl",
								children: ["Ce qui peut vous amener à ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "italic text-gold",
									children: "consulter"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "reveal mx-auto mt-6 max-w-2xl text-base font-light leading-relaxed text-inkmuted sm:text-lg",
								children: "Que ce soit pour des maux physiques ou émotionnels, en présentiel ou à distance."
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "reveal mx-auto mt-14 flex max-w-4xl flex-wrap justify-center gap-3",
						children: motifs.map((motif) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full border border-ink/15 bg-cream/70 px-5 py-2.5 text-sm font-medium text-ink/80 transition-all duration-300 hover:border-gold hover:bg-cream hover:text-ink",
							children: motif
						}, motif))
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				id: "soins",
				className: "mx-auto max-w-7xl scroll-mt-24 px-6 py-28 lg:px-12 lg:py-40",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid items-end gap-10 lg:grid-cols-[1fr_auto]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "max-w-3xl",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex items-center gap-3",
								children: "Les soins"
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "reveal mt-8 text-center font-display text-5xl font-light leading-[1.05] tracking-tight sm:text-6xl lg:text-left",
								children: ["Six chemins vers ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "italic text-gold",
									children: "l'équilibre"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "reveal mt-5 text-sm font-light text-inkmuted lg:text-left",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Tarifs en vigueur au 15/10/2026." })
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "reveal hidden overflow-hidden rounded-[2rem] lg:block lg:w-64",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: IMAGES.stones,
							alt: "Pierres zen empilées",
							className: "aspect-square w-full object-cover transition-transform duration-700 hover:scale-105",
							loading: "lazy"
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-20",
					children: soins.map((soin) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "group grid gap-8 border-t border-ink/15 py-14 transition-all duration-500 last:border-b hover:bg-sand/40 lg:grid-cols-[auto_1fr_auto] lg:gap-16 lg:px-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display text-5xl font-light italic text-gold/70 transition-colors duration-500 group-hover:text-gold lg:text-6xl",
								children: soin.num
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-3xl font-medium leading-tight text-ink sm:text-4xl",
									children: soin.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-5 max-w-2xl text-base font-light leading-relaxed text-inkmuted",
									children: soin.description
								}),
								soin.description2 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-6 max-w-2xl text-base font-light leading-relaxed text-inkmuted",
									children: soin.description2
								}),
								soin.extra && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
									className: "mt-6 grid gap-4 sm:grid-cols-2",
									children: soin.extra.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-2xl border border-ink/10 bg-cream p-5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
												className: "text-[11px] font-semibold uppercase tracking-[0.2em] text-gold",
												children: item.label
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
												className: "mt-2 text-sm font-light leading-relaxed text-inkmuted",
												children: item.text
											}),
											item.note && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-4 text-sm leading-relaxed text-rosedeep",
												children: item.note.split("\n").map((line, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: `block ${index === 1 ? "font-bold" : ""}`,
													children: index === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Option" }), line.slice(6)] }) : line
												}, line))
											}),
											item.label === "Huiles de massage" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HuilesMassageDetails, {})
										]
									}, item.label))
								})
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
								className: "flex flex-col gap-4 lg:min-w-64 lg:text-right",
								children: soin.meta.map((m, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [m.label && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-[11px] font-semibold uppercase tracking-[0.2em] text-ink/50",
									children: m.label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: m.label ? "mt-1 font-display text-xl font-medium text-ink" : "font-display text-xl font-medium text-ink",
									children: m.value
								})] }, `${m.label}-${i}`))
							})
						]
					}, soin.num))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "border-y border-ink/10 bg-sand/50 py-28 lg:py-36",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-7xl px-6 lg:px-12",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: "Après un soin" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "reveal mt-8 font-display text-5xl font-light leading-[1.05] tracking-tight sm:text-6xl",
								children: ["Réactions éventuelles ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "italic text-gold",
									children: "après un soin"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "reveal mx-auto mt-8 max-w-3xl text-center text-base font-light leading-relaxed text-inkmuted sm:text-lg",
							children: "Après un soin énergétique, certaines personnes continuent à ressentir des émotions ou des sensations pendant quelque temps. Ces réactions varient d'une personne à l'autre — et le bien-être n'est pas toujours immédiat. Ne rien ressentir pendant la séance ne signifie pas une absence d'effet."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "reveal mt-16 grid gap-px overflow-hidden rounded-3xl border border-ink/10 bg-ink/10 sm:grid-cols-2 lg:grid-cols-3",
							children: reactions.map((reaction) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "group bg-cream p-8 transition-colors duration-500 hover:bg-sand",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-display text-3xl font-light italic text-gold/60 transition-colors duration-500 group-hover:text-gold",
										children: "✦"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-4 font-display text-2xl font-medium text-ink",
										children: reaction.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 text-sm font-light leading-relaxed text-inkmuted",
										children: reaction.text
									})
								]
							}, reaction.title))
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				id: "a-propos",
				className: "mx-auto max-w-7xl scroll-mt-24 px-6 py-28 lg:px-12 lg:py-40",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-3xl text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: "À propos" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "reveal mt-8 font-display text-5xl font-light leading-[1.05] tracking-tight sm:text-6xl",
						children: [
							"Qui ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "italic text-gold",
								children: "suis-je"
							}),
							" ?"
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "reveal mx-auto mt-16 max-w-2xl space-y-6 text-base font-light leading-relaxed text-inkmuted sm:text-lg",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Après une première vie professionnelle classique, j'ai ressenti l'appel profond de ma mission de vie : accompagner les autres sur leur chemin. La seule intention que je pose est de vous aider à retrouver davantage de paix, d'amour et de lumière en vous." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-[13px] font-semibold uppercase tracking-[0.3em] text-gold",
							children: "Formations"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-5 space-y-3",
							children: formations.map((formation) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center gap-4 border-b border-ink/10 pb-3 font-display text-xl font-medium text-ink",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-gold",
									children: "✦"
								}), formation]
							}, formation))
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("blockquote", {
							className: "border-l-2 border-gold pl-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-2xl font-light italic leading-snug text-ink",
								children: "« La clé, c'est vous ! »"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("cite", {
								className: "mt-3 block text-xs font-semibold uppercase tracking-[0.25em] not-italic text-gold",
								children: "— Cathy"
							})]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "border-y border-ink/10 bg-creamsoft py-24 lg:py-32",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-3xl px-6 text-center lg:px-12",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: "Avis Google" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "reveal mt-8 font-display text-5xl font-light leading-[1.05] tracking-tight sm:text-6xl",
							children: "Votre expérience compte"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "reveal mx-auto mt-6 max-w-2xl text-base font-light leading-relaxed text-inkmuted sm:text-lg",
							children: "Votre témoignage peut être précieux pour une personne qui a besoin d'aide. Elle peut décider de sortir de sa problématique."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "https://www.google.com/maps/place/Cathy+Bultez+-+Praticienne+en+Massages+et+Bien-Etre/@50.2445525,3.6416956,17z/data=!3m1!4b1!4m6!3m5!1s0x47c28bbe74794fd9:0x94daa5c5b0e3d7e!8m2!3d50.2445525!4d3.6442705!16s%2Fg%2F11krdl445g?entry=ttu",
							target: "_blank",
							rel: "noreferrer",
							className: "reveal mt-8 inline-flex rounded-full border border-ink/15 px-7 py-3.5 text-sm font-semibold uppercase tracking-[0.15em] text-ink transition-colors hover:border-gold hover:bg-gold hover:text-cream",
							children: "Lire les avis Google"
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				id: "bon-cadeau",
				className: "relative mx-4 scroll-mt-24 overflow-hidden rounded-[3rem] bg-gradient-to-br from-goldbright via-gold to-golddeep py-24 text-cream sm:mx-6 lg:mx-10 lg:py-32",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "pointer-events-none absolute -right-10 -top-24 select-none font-display text-[26rem] font-light italic leading-none text-cream/15",
						children: "*"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute -bottom-32 -left-24 h-96 w-96 rounded-full bg-cream/10 blur-3xl" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "relative mx-auto max-w-7xl px-6 lg:px-12",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto max-w-3xl text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "reveal flex items-center justify-center gap-3 text-[13px] font-semibold uppercase tracking-[0.3em] text-cream/80",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gift, { className: "h-4 w-4" }), "Offrir un moment de soin"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
									className: "reveal mt-8 font-display text-5xl font-light leading-[1.05] tracking-tight sm:text-6xl",
									children: ["Le ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "italic",
										children: "bon cadeau"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "reveal mt-8 text-base font-light leading-relaxed text-cream/90 sm:text-lg",
									children: [
										"Pour un anniversaire, Noël, la Saint-Valentin, un enterrement de vie de jeune fille, une naissance ou la fête des Mères et Grands-Mères — offrez une parenthèse de bien-être. Le montant est libre et peut être déduit d'une prestation. Bon valable",
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-semibold",
											children: "6 mois"
										}),
										" à compter de la date d'achat."
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "reveal mt-5 text-sm font-light leading-relaxed text-cream/75",
									children: "Réservation sur place à Romeries ou par mail."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: "tel:0610197558",
									className: "reveal group mt-10 inline-flex items-center gap-3 rounded-full bg-cream px-9 py-4 text-sm font-semibold uppercase tracking-[0.15em] text-ink transition-all duration-300 hover:bg-ink hover:text-cream",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "h-4 w-4 transition-transform duration-300 group-hover:rotate-12" }), "06 10 19 75 58"]
								})
							]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-24 lg:h-32" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
		]
	});
}
//#endregion
export { HomePage as component };
