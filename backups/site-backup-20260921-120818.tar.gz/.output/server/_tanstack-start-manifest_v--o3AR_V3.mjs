//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v--o3AR_V3.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspaces/html-site-builder-00/src/routes/__root.tsx",
		children: ["/", "/mentions-legales"],
		preloads: ["/assets/index-B3W-VVch.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-B3W-VVch.js"
		} }]
	},
	"/": {
		filePath: "/workspaces/html-site-builder-00/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-ByEiYq4q.js", "/assets/Footer-DijlwiJp.js"]
	},
	"/mentions-legales": {
		filePath: "/workspaces/html-site-builder-00/src/routes/mentions-legales.tsx",
		children: void 0,
		preloads: ["/assets/mentions-legales-BcfNcyST.js", "/assets/Footer-DijlwiJp.js"]
	}
} });
//#endregion
export { tsrStartManifest };
